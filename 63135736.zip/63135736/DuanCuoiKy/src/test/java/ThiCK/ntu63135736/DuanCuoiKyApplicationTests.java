package ThiCK.ntu63135736;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuanCuoiKyApplicationTests {

	@Test
	void contextLoads() {
	}

}
