package ThiCK.ntu63135736;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DuanCuoiKyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DuanCuoiKyApplication.class, args);
	}

}
