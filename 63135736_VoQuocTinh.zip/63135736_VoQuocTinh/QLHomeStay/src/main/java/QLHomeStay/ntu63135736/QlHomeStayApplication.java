package QLHomeStay.ntu63135736;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QlHomeStayApplication {

	public static void main(String[] args) {
		SpringApplication.run(QlHomeStayApplication.class, args);
	}

}
