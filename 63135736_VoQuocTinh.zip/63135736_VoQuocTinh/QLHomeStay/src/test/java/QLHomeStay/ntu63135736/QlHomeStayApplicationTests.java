package QLHomeStay.ntu63135736;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QlHomeStayApplicationTests {

	@Test
	void contextLoads() {
	}

}
