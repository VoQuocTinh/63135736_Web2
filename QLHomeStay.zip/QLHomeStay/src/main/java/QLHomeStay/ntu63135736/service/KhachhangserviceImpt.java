package QLHomeStay.ntu63135736.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import QLHomeStay.ntu63135736.model.Khachhangmodel;
import QLHomeStay.ntu63135736.responsitory.Khachhangresponsitory;
@Service
public class KhachhangserviceImpt implements Khachhangservice {
	 
}
