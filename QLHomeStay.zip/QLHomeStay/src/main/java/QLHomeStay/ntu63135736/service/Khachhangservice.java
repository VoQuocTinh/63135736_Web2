package QLHomeStay.ntu63135736.service;

import java.util.List;

import org.springframework.stereotype.Service;

import QLHomeStay.ntu63135736.model.Khachhangmodel;

@Service
public interface Khachhangservice {

}
